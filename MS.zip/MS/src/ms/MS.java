package ms;
public class MS {
    public static void main(String[] args) {
        Sweep sw = new Sweep();
        sw.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        sw.show();
    }
}
